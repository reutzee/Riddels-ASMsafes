java -cp lib/corewars8086-4.0.1.jar il.co.codeguru.corewars8086.CoreWarsEngine
